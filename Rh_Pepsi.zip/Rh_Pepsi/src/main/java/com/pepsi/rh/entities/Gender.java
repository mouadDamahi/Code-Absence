package com.pepsi.rh.entities;

public enum Gender {

	Male,Female
}
