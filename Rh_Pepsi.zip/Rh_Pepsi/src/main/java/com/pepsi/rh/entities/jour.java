package com.pepsi.rh.entities;

public enum jour {
 M,AM
}
