package com.pepsi.rh.entities;

public enum Situation {
	 Marier, Divorcer,Celibataire;
}
