package com.pepsi.rh.entities;

public enum Raison {

	Maladie, Autorisee,Conge_Annuel,
	Maternite,Mariage,Deces,Circoncision,
	Naissance,Allaitement,Formation,Absence_RP,Accident_de_travail,
	Recuperation_Heures_Supp,Autorisation_de_sortie,Mission,Mise_a_pied,OMRA,HAJ,
	Arret_Production,Absence_Preavis,Operation_Chirurgicale,Retard_Transport,Sick_Leave;
}
